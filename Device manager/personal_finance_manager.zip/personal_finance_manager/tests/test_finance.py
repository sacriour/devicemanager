import os
import tempfile
from managers.account_manager import AccountManager
from managers.transaction_manager import TransactionManager
from managers.budget_manager import BudgetManager
from storage.csv_storage import CSVStorage
import pytest

# Unit test: Account creation and validation
def test_account_create_and_read():
    storage = CSVStorage(base_path=tempfile.mkdtemp())
    am = AccountManager(storage)
    acc = am.create('A1','Wallet','cash','HUF')
    assert acc.id == 'A1'
    assert am.read('A1').name == 'Wallet'
    with pytest.raises(Exception):
        am.create('A1','Dup','cash','HUF')  # duplicate id

# Integration test: create account then transaction referencing it
def test_transaction_with_account():
    storage = CSVStorage(base_path=tempfile.mkdtemp())
    am = AccountManager(storage)
    tm = TransactionManager(storage, am)
    am.create('A2','Bank','bank','EUR')
    tx = tm.create('T1','A2','2025-11-01',100.0,'Salary','income')
    assert tx.amount == 100.0
    assert tm.read('T1').account_id == 'A2'

# System test: save and load flow
def test_save_load_cycle(tmp_path):
    base = tmp_path / 'data'
    storage = CSVStorage(base_path=str(base))
    am = AccountManager(storage)
    tm = TransactionManager(storage, am)
    bm = BudgetManager(storage)
    am.create('A3','Cash','cash','USD')
    tm.create('T2','A3','2025-10-10',-20.5,'Lunch','food')
    bm.create('B1','2025-10','food',200)
    storage.save_all(am, tm, bm)
    # create new managers and load
    am2 = AccountManager(storage)
    tm2 = TransactionManager(storage, am2)
    bm2 = BudgetManager(storage)
    storage.load_all(am2, tm2, bm2)
    assert am2.read('A3').currency == 'USD'
    assert tm2.read('T2').description == 'Lunch'
    assert bm2.read('B1').limit_amount == 200.0
