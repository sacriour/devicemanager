from dataclasses import dataclass
from datetime import datetime

@dataclass
class Transaction:
    id: str
    account_id: str
    date: str  # ISO date
    amount: float
    description: str
    category: str

    def to_dict(self):
        return {'id': self.id, 'account_id': self.account_id, 'date': self.date, 'amount': self.amount, 'description': self.description, 'category': self.category}

    def __str__(self):
        return f"Transaction(id={self.id}, account_id={self.account_id}, date={self.date}, amount={self.amount}, desc={self.description}, cat={self.category})"

class ExpenseTransaction(Transaction):
    pass

class IncomeTransaction(Transaction):
    pass
