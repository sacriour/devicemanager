from dataclasses import dataclass

@dataclass
class Budget:
    id: str
    month: str  # e.g. 2025-11
    category: str
    limit_amount: float

    def to_dict(self):
        return {'id': self.id, 'month': self.month, 'category': self.category, 'limit_amount': self.limit_amount}

    def __str__(self):
        return f"Budget(id={self.id}, month={self.month}, category={self.category}, limit={self.limit_amount})"
