from dataclasses import dataclass

@dataclass
class Account:
    id: str
    name: str
    account_type: str
    currency: str

    def to_dict(self):
        return {'id': self.id, 'name': self.name, 'account_type': self.account_type, 'currency': self.currency}

    def __str__(self):
        return f"Account(id={self.id}, name={self.name}, type={self.account_type}, currency={self.currency})"

class CashAccount(Account):
    pass

class BankAccount(Account):
    pass
