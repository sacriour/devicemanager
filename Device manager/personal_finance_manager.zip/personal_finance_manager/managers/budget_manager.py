from models.budget import Budget
from exceptions import ValidationError, NotFoundError

class BudgetManager:
    def __init__(self, storage):
        self.storage = storage
        self.budgets = {}

    def create(self, id, month, category, limit_amount):
        if id in self.budgets:
            raise ValidationError('Duplicate budget id')
        b = Budget(id=id, month=month, category=category, limit_amount=float(limit_amount))
        self.budgets[id] = b
        return b

    def read(self, id):
        try:
            return self.budgets[id]
        except KeyError:
            raise NotFoundError('Budget not found')

    def update(self, id, **kwargs):
        b = self.read(id)
        for k,v in kwargs.items():
            if hasattr(b, k): setattr(b, k, v)
        return b

    def delete(self, id):
        if id in self.budgets:
            return self.budgets.pop(id)
        raise NotFoundError('Budget not found')

    def list_all(self):
        return list(self.budgets.values())

    def load_from_list(self, rows):
        self.budgets = {}
        for r in rows:
            self.create(r['id'], r['month'], r['category'], r['limit_amount'])

    def export_to_list(self):
        return [b.to_dict() for b in self.budgets.values()]

    # interactive helpers
    def create_interactive(self):
        id = input('id: ').strip()
        month = input('month (YYYY-MM): ').strip()
        category = input('category: ').strip()
        limit = input('limit amount: ').strip()
        try:
            b = self.create(id, month, category, limit)
            print('Created', b)
        except Exception as e:
            print('Error:', e)

    def update_interactive(self):
        id = input('id to update: ').strip()
        try:
            b = self.read(id)
            month = input(f'month [{b.month}]: ').strip() or b.month
            category = input(f'category [{b.category}]: ').strip() or b.category
            limit = input(f'limit [{b.limit_amount}]: ').strip() or b.limit_amount
            self.update(id, month=month, category=category, limit_amount=float(limit))
            print('Updated', self.read(id))
        except Exception as e:
            print('Error:', e)

    def delete_interactive(self):
        id = input('id to delete: ').strip()
        try:
            self.delete(id)
            print('Deleted', id)
        except Exception as e:
            print('Error:', e)
