from models.transaction import Transaction, ExpenseTransaction, IncomeTransaction
from exceptions import ValidationError, NotFoundError
from datetime import datetime

class TransactionManager:
    def __init__(self, storage, account_manager):
        self.storage = storage
        self.tx = {}  # id -> Transaction
        self.account_manager = account_manager

    def create(self, id, account_id, date, amount, description, category):
        if id in self.tx:
            raise ValidationError('Duplicate transaction id')
        # simple validation
        self.account_manager.read(account_id)  # raises if missing
        try:
            # allow date strings or datetime
            if isinstance(date, datetime):
                date = date.date().isoformat()
            else:
                # basic parse check
                datetime.fromisoformat(date)
        except Exception:
            raise ValidationError('Invalid date format, use YYYY-MM-DD')
        amount = float(amount)
        cls = ExpenseTransaction if amount<0 else IncomeTransaction
        t = cls(id=id, account_id=account_id, date=date, amount=amount, description=description, category=category)
        self.tx[id] = t
        return t

    def read(self, id):
        try:
            return self.tx[id]
        except KeyError:
            raise NotFoundError('Transaction not found')

    def update(self, id, **kwargs):
        t = self.read(id)
        for k,v in kwargs.items():
            if hasattr(t, k):
                setattr(t, k, v)
        return t

    def delete(self, id):
        if id in self.tx:
            return self.tx.pop(id)
        raise NotFoundError('Transaction not found')

    def list_all(self):
        return list(self.tx.values())

    def load_from_list(self, rows):
        self.tx = {}
        for r in rows:
            self.create(r['id'], r['account_id'], r['date'], r['amount'], r['description'], r['category'])

    def export_to_list(self):
        return [t.to_dict() for t in self.tx.values()]

    # interactive helpers
    def create_interactive(self):
        id = input('id: ').strip()
        account_id = input('account_id: ').strip()
        date = input('date (YYYY-MM-DD): ').strip()
        amount = input('amount (use negative for expense): ').strip()
        description = input('description: ').strip()
        category = input('category: ').strip()
        try:
            t = self.create(id, account_id, date, amount, description, category)
            print('Created', t)
        except Exception as e:
            print('Error:', e)

    def update_interactive(self):
        id = input('id to update: ').strip()
        try:
            t = self.read(id)
            date = input(f'date [{t.date}]: ').strip() or t.date
            amount = input(f'amount [{t.amount}]: ').strip() or t.amount
            description = input(f'description [{t.description}]: ').strip() or t.description
            category = input(f'category [{t.category}]: ').strip() or t.category
            self.update(id, date=date, amount=float(amount), description=description, category=category)
            print('Updated', self.read(id))
        except Exception as e:
            print('Error:', e)

    def delete_interactive(self):
        id = input('id to delete: ').strip()
        try:
            self.delete(id)
            print('Deleted', id)
        except Exception as e:
            print('Error:', e)
