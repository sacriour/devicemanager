import os
from models.account import Account, CashAccount, BankAccount
from exceptions import ValidationError, NotFoundError

class AccountManager:
    def __init__(self, storage):
        self.storage = storage
        self.accounts = {}  # id -> Account

    def create(self, id, name, account_type, currency):
        if id in self.accounts:
            raise ValidationError('Duplicate account id')
        cls = CashAccount if account_type=='cash' else BankAccount
        acc = cls(id=id, name=name, account_type=account_type, currency=currency)
        self.accounts[id] = acc
        return acc

    def read(self, id):
        try:
            return self.accounts[id]
        except KeyError:
            raise NotFoundError('Account not found')

    def update(self, id, **kwargs):
        acc = self.read(id)
        for k,v in kwargs.items():
            if hasattr(acc, k): setattr(acc, k, v)
        return acc

    def delete(self, id):
        if id in self.accounts:
            return self.accounts.pop(id)
        raise NotFoundError('Account not found')

    def list_all(self):
        return list(self.accounts.values())

    def load_from_list(self, rows):
        self.accounts = {}
        for r in rows:
            self.create(r['id'], r['name'], r['account_type'], r['currency'])

    def export_to_list(self):
        return [a.to_dict() for a in self.accounts.values()]

    # interactive helpers
    def create_interactive(self):
        id = input('id: ').strip()
        name = input('name: ').strip()
        account_type = input('type (cash/bank): ').strip() or 'cash'
        currency = input('currency: ').strip() or 'HUF'
        try:
            acc = self.create(id, name, account_type, currency)
            print('Created', acc)
        except ValidationError as e:
            print('Error:', e)

    def update_interactive(self):
        id = input('id to update: ').strip()
        try:
            acc = self.read(id)
            name = input(f'name [{acc.name}]: ').strip() or acc.name
            account_type = input(f'type [{acc.account_type}]: ').strip() or acc.account_type
            currency = input(f'currency [{acc.currency}]: ').strip() or acc.currency
            self.update(id, name=name, account_type=account_type, currency=currency)
            print('Updated', self.read(id))
        except Exception as e:
            print('Error:', e)

    def delete_interactive(self):
        id = input('id to delete: ').strip()
        try:
            self.delete(id)
            print('Deleted', id)
        except Exception as e:
            print('Error:', e)
