# Personal Finance Manager (CLI)

Simple command-line personal finance manager supporting Accounts, Transactions, and Budgets.
- OOP design with models and managers.
- CSV persistence (data/ folder).
- Custom exceptions and basic validation.
- Menu-driven CLI (`main.py`).
- Tests with `pytest` (see `tests/test_finance.py`).

## Install & Run

```bash
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
python main.py
```

## Project structure
See files in the repository. Data saved to `data/accounts.csv`, `data/transactions.csv`, `data/budgets.csv`.

## Testing
```bash
pytest -q
```

## Example CSVs
Example CSVs are generated after you run `Save to CSV` or by running tests.
