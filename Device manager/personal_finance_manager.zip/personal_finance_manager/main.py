from managers.account_manager import AccountManager
from managers.transaction_manager import TransactionManager
from managers.budget_manager import BudgetManager
from storage.csv_storage import CSVStorage
from exceptions import FinanceError

def print_menu():
    print("""
Personal Finance Manager
1. Manage Accounts
2. Manage Transactions
3. Manage Budgets
4. Save to CSV
5. Load from CSV
6. Exit
""")

def submenu(title, actions):
    while True:
        print(f"\n{title}")
        for k,v in actions.items():
            print(f"{k}. {v['label']}")
        choice = input("Choose: ").strip()
        if choice in actions:
            actions[choice]['func']()
        else:
            print("Invalid choice")
        if choice == '0':
            break

def main():
    storage = CSVStorage(base_path='data')
    acc_mgr = AccountManager(storage)
    tx_mgr = TransactionManager(storage, acc_mgr)
    bdg_mgr = BudgetManager(storage)
    try:
        while True:
            print_menu()
            choice = input('Select: ').strip()
            if choice == '1':
                actions = {
                    '1': {'label':'List Accounts', 'func': lambda: print('\n'.join(map(str, acc_mgr.list_all())) or 'No accounts')},
                    '2': {'label':'Create Account', 'func': lambda: acc_mgr.create_interactive()},
                    '3': {'label':'Update Account', 'func': lambda: acc_mgr.update_interactive()},
                    '4': {'label':'Delete Account', 'func': lambda: acc_mgr.delete_interactive()},
                    '0': {'label':'Back', 'func': lambda: None},
                }
                submenu('Manage Accounts', actions)
            elif choice == '2':
                actions = {
                    '1': {'label':'List Transactions', 'func': lambda: print('\n'.join(map(str, tx_mgr.list_all())) or 'No transactions')},
                    '2': {'label':'Create Transaction', 'func': lambda: tx_mgr.create_interactive()},
                    '3': {'label':'Update Transaction', 'func': lambda: tx_mgr.update_interactive()},
                    '4': {'label':'Delete Transaction', 'func': lambda: tx_mgr.delete_interactive()},
                    '0': {'label':'Back', 'func': lambda: None},
                }
                submenu('Manage Transactions', actions)
            elif choice == '3':
                actions = {
                    '1': {'label':'List Budgets', 'func': lambda: print('\n'.join(map(str, bdg_mgr.list_all())) or 'No budgets')},
                    '2': {'label':'Create Budget', 'func': lambda: bdg_mgr.create_interactive()},
                    '3': {'label':'Update Budget', 'func': lambda: bdg_mgr.update_interactive()},
                    '4': {'label':'Delete Budget', 'func': lambda: bdg_mgr.delete_interactive()},
                    '0': {'label':'Back', 'func': lambda: None},
                }
                submenu('Manage Budgets', actions)
            elif choice == '4':
                storage.save_all(acc_mgr, tx_mgr, bdg_mgr)
                print('Saved to CSV.')
            elif choice == '5':
                storage.load_all(acc_mgr, tx_mgr, bdg_mgr)
                print('Loaded from CSV.')
            elif choice == '6':
                print('Goodbye')
                break
            else:
                print('Invalid option')
    except FinanceError as e:
        print('Error:', e)
    except KeyboardInterrupt:
        print('\nExiting...')

if __name__ == '__main__':
    main()
