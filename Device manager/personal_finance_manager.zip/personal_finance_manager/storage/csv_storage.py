import os, csv
from exceptions import StorageError

class CSVStorage:
    def __init__(self, base_path='data'):
        self.base_path = base_path
        os.makedirs(self.base_path, exist_ok=True)

    def save(self, filename, rows, fieldnames):
        path = os.path.join(self.base_path, filename)
        try:
            with open(path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for r in rows:
                    writer.writerow(r)
        except Exception as e:
            raise StorageError(str(e))

    def load(self, filename):
        path = os.path.join(self.base_path, filename)
        if not os.path.exists(path):
            return []
        try:
            with open(path, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                return [row for row in reader]
        except Exception as e:
            raise StorageError(str(e))

    def save_all(self, acc_mgr, tx_mgr, bdg_mgr):
        self.save('accounts.csv', acc_mgr.export_to_list(), ['id','name','account_type','currency'])
        self.save('transactions.csv', tx_mgr.export_to_list(), ['id','account_id','date','amount','description','category'])
        self.save('budgets.csv', bdg_mgr.export_to_list(), ['id','month','category','limit_amount'])

    def load_all(self, acc_mgr, tx_mgr, bdg_mgr):
        acc_rows = self.load('accounts.csv')
        tx_rows = self.load('transactions.csv')
        bdg_rows = self.load('budgets.csv')
        if acc_rows:
            acc_mgr.load_from_list(acc_rows)
        if tx_rows:
            tx_mgr.load_from_list(tx_rows)
        if bdg_rows:
            bdg_mgr.load_from_list(bdg_rows)
